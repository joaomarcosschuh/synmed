import 'package:flutter/material.dart';
import 'package:meu_flash/models/dailystats_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:meu_flash/models/user_model.dart';
import 'package:intl/intl.dart'; // Import to format the birthdate

class CategoryHeader extends StatefulWidget {
  final Map<String, Set<String>> categories;
  final GlobalKey headerKey;
  final DailyStatsModel dailyStatsModel;
  final UserModel user;

  static const double circleAvatarRadius = 30;
  static const double circleAvatarPadding = 8.0;

  CategoryHeader({
    required this.categories,
    required this.headerKey,
    required this.dailyStatsModel,
    required this.user,
  });

  @override
  _CategoryHeaderState createState() => _CategoryHeaderState();
}

class _CategoryHeaderState extends State<CategoryHeader> {
  // Initialize the selectedCategories set with the desired default selected categories.
  Set<String> selectedCategories = {'category1', 'category2'};

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60 + 2 * CategoryHeader.circleAvatarPadding + 2 * CategoryHeader.circleAvatarRadius,
      child: Stack(
        children: [
          Positioned(
            top: 8,
            left: 8,
            child: Image.asset(
              'lib/assets/logo/text_logo.png',
              width: 120,
              height: 60,
            ),
          ),
          Positioned(
            top: 10,
            right: 10,
            child: Row(
              children: [
                Image.asset(
                  'lib/assets/simbolos/foguinho.png',
                  height: 28,
                ),
                SizedBox(width: 2),
                Text(
                  '${widget.dailyStatsModel.streak}',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(width: 15),
                Image.asset(
                  'lib/assets/simbolos/xp.png',
                  height: 45,
                ),
                SizedBox(width: 2),
                Text(
                  '${widget.dailyStatsModel.xpDia}',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: 65,
            left: 8,
            right: 8,
            child: Container(
              height: 2 * CategoryHeader.circleAvatarRadius + 2 * CategoryHeader.circleAvatarPadding,
              child: ListView.builder(
                padding: EdgeInsets.zero,
                scrollDirection: Axis.horizontal,
                itemCount: widget.categories.length + 1,
                itemBuilder: (context, index) {
                  if (index == 0) {
                    return Padding(
                      padding: const EdgeInsets.all(CategoryHeader.circleAvatarPadding),
                      child: CircleAvatar(
                        radius: CategoryHeader.circleAvatarRadius,
                        backgroundImage: _buildProfileImage(),
                      ),
                    );
                  }

                  final category = widget.categories.keys.elementAt(index - 1);
                  return Padding(
                    padding: const EdgeInsets.all(CategoryHeader.circleAvatarPadding),
                    child: InkWell(
                      onTap: () {
                        // Toggle selection only for the second and third circles (category1 and category2)
                        if (category == 'category1' || category == 'category2') {
                          setState(() {
                            if (selectedCategories.contains(category)) {
                              selectedCategories.remove(category);
                            } else {
                              selectedCategories.add(category);
                            }
                          });
                        }
                      },
                      child: Stack(
                        children: [
                          CircleAvatar(
                            radius: CategoryHeader.circleAvatarRadius,
                            backgroundImage: AssetImage(
                              'lib/assets/${category.toLowerCase()}.jpg',
                            ),
                          ),
                          if (selectedCategories.contains(category))
                            Positioned(
                              bottom: 0,
                              right: 0,
                              child: Icon(
                                Icons.check_circle,
                                color: Colors.green,
                              ),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          // Add an empty circle if the user has no categories selected
          if (selectedCategories.isEmpty)
            Positioned(
              top: 65,
              left: 8 + CategoryHeader.circleAvatarPadding + CategoryHeader.circleAvatarRadius,
              child: CircleAvatar(
                radius: CategoryHeader.circleAvatarRadius,
                backgroundColor: Colors.transparent,
              ),
            ),
        ],
      ),
    );
  }

  ImageProvider _buildProfileImage() {
    if (widget.user.profilePicture != null && widget.user.profilePicture is String) {
      // If the profilePicture is a URL, use NetworkImage
      return NetworkImage(widget.user.profilePicture);
    } else if (widget.user.profilePicture != null && widget.user.profilePicture is String) {
      // If the profilePicture is a file path, use AssetImage
      return AssetImage(widget.user.profilePicture);
    } else {
      // If the profilePicture is not provided or is not a valid URL or file path,
      // you can use a default image asset or return an empty AssetImage as a fallback.
      return AssetImage('lib/assets/profile_picture.png');
    }
  }
}
